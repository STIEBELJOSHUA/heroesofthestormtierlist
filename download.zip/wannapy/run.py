import os

os.system('python3 main.py')